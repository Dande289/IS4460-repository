#django-admin startproject model_lab
#pythom manage.py startapp customer
#pythom manage.py migrate
#pythom manage.py makemigrations
#pythom manage.py migrate
#python manage.py shell
#from customer.models import Customer
#my_new_customer = Customer()
#my_new_customer.name = "Dillons Name"
#my_new_customer.save()
#customer_two = Customer()
#customer_two.name = "Dillon Enterprises"
#customer_two.save()
#customer_three = Customer()
#customer_three.name = "XYZ Company"
#customer_three.save()
#customer_four = Customer()
#customer_four.name = "Customer4 Name"
#customer_four.save()
#Customer.objects.get(pk=1)
#customer_one.name =
#customer_one.name = "Dillons new Name"
#customer_one.save()
#customer_one.delete()
#results = Customer.objects.exclude(name__startswith=("Dillon"))
#results.count()
#results[0].name
#results[1].name
#results[2].name
#customer[0].name
#customer[1].name
#customer[2].name
#customer[3].name
#the_customer = Customer.objects.get(pk=4)
#from customer.models import Customer,Order
#order1
#order1 = Order(customer=the_customer,total_price=24.99,total_items=3)
#order1.save()
#order2 = Order(customer=the_customer,total_price=12.99,total_items=1)
#order2.save()
#customer_one.email = "test@test.com"
#customer_one.save()
#customer_one.email
#customer_one.name
