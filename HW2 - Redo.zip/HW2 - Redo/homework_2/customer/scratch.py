from customer.models import Movie


#4. Write Django QuerySet statements for Movie:


#Retrieve all movies
all_movies = Movie.objects.all()
print(all_movies)
#<QuerySet [<Movie: Movie object (1)>, <Movie: Movie object (2)>, <Movie: Movie object (3)>, <Movie: Movie object (4)>, 
#           <Movie: Movie object (5)>, <Movie: Movie object (6)>, <Movie: Movie object (7)>, <Movie: Movie object (8)>, 
#           <Movie: Movie object (9)>, <Movie: Movie object (10)>]>


#Filter for movies starting with some text
movie_filter = Movie.objects.filter(title="Toy Story")
print(movie_filter)
#<QuerySet [<Movie: Movie object (2)>]>


#Get one movie
get_movie = Movie.objects.get(title="Austin Powers")
print(get_movie)
#Movie object (9)


#Update one movie
update_movie = Movie.objects.get(title="Austin Powers")
update_movie.director = "Jay Roach"
update_movie.save()


#Delete one movie
delete_movie = Movie.objects.get(title="Austin Powers")
delete_movie.delete()
#(1, {'customer.Movie': 1})


from customer.models import User

#5. Write Django model statements for User model:

 
user_model = User.objects.get(username = "username2")
print(f"Username:{user_model.username}")  
#Username:username2
print(f"First name: {user_model.first_name}")
#First name: Robert
print(f"Last name: {user_model.last_name}")
#Last name: Anderson
print(f"Email: {user_model.email}")
#Email: test2@test.com
