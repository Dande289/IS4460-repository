# This is a comment using python

#literals
print('Han Solo')
print(3.333)

#variable names
C = 6
c = 7

print(C)
print(c)

user_name = "Han Solo"
gpa = 3.333

print(user_name)
print(gpa)

print("My name is " + user_name + " not Dillon")

print(f"My name is {user_name} not Dillon")

number = 4567 * 4856
print(str(number)[1:3])

def add_numbers(c,d):
    output = c + d
    return output

print(add_numbers(4,5))
print(add_numbers(c=7, d=5))

name = "Dillon"

def say_hello():
    name = "Arantza"
    return f"hello {name}"

print(say_hello())





